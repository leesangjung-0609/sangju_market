const express = require("express");
const app = express();
const path = require("path");
const os = require("os");
const session = require("express-session"); // 세션 모듈
const cors = require("cors");

app.set('trust proxy', 1);

// server.js의 CORS 설정 수정
app.use(cors({
  origin: function(origin, callback){
    // [수정된 부분] localhost가 포함된 요청도 허용
    if(!origin || origin.endsWith("ngrok-free.dev") || origin.includes("localhost")) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true
}));

app.use(
  session({
    secret: "secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
	httpOnly: true,
      	secure: true,      
      	sameSite: "none",   
	maxAge: 1000 * 60 * 60 * 24     
	}
  })
);

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());


const userRouter = require("./routes/user");
const commentRouter = require("./routes/comment");
const productRouter = require("./routes/product");
const reviewRouter = require("./routes/review");
const wishlistRouter = require("./routes/wishlist");

app.use("/product", productRouter);
app.use("/user", userRouter);
app.use("/comment", commentRouter);
app.use("/review", reviewRouter);
app.use("/wishlist", wishlistRouter);


app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "main.html"));
});

const PORT = 3000;
const HOST = '0.0.0.0';
app.listen(PORT, HOST, () => {
  const nets = os.networkInterfaces();
  let localIp = "localhost";
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        localIp = net.address;
      }
    }
  }
  console.log(`서버 실행됨: http://${localIp}:${PORT}`);
});
