from flask import Flask, request, send_file, render_template
import mysql.connector
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

app = Flask(__name__)

DB_CONFIG = {
    "host": "155.230.241.241",
    "user": "team3_nam",
    "password": "team3_nam##",
    "database": "univ_db_team3"
}

# ----------------------------
# DB 조회 함수
# ----------------------------
def get_sections():
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        SELECT s.course_id, c.title, s.sec_id, s.semester, s.year
        FROM section s
        JOIN course c ON s.course_id = c.course_id
        ORDER BY c.title, s.year DESC, s.semester DESC, s.sec_id ASC
    """
    cursor.execute(query)
    rows = cursor.fetchall()  # (course_id, title, sec_id, semester, year)
    cursor.close()
    conn.close()
    return rows

def get_students(course_id, sec_id, semester, year):
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    query = """
        SELECT s.id, s.name, s.dept_name
        FROM takes t
        JOIN student s ON t.id = s.id
        WHERE t.course_id = %s AND t.sec_id = %s AND t.semester = %s AND t.year = %s
        ORDER BY s.id
    """
    cursor.execute(query, (course_id, sec_id, semester, year))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows

# ----------------------------
# PDF 생성
# ----------------------------
def create_attendance_pdf(course_title, sec_id, semester, year, students, filename="attendance.pdf"):
    doc = SimpleDocTemplate(filename, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=30, bottomMargin=30)
    elements = []
    styles = getSampleStyleSheet()
    name_style = ParagraphStyle(name='NameStyle', fontSize=9, leading=10)

    # 제목
    title = Paragraph(f"Attendance Sheet - {course_title} ({sec_id}SEC)", styles["Title"])
    subtitle = Paragraph(f"{year}YEAR {semester}SEMESTER", styles["Heading2"])
    elements.append(title)
    elements.append(subtitle)
    elements.append(Spacer(1, 20))

    # 테이블 헤더 2행
    header1 = ["Student ID", "Name", "Department"] + [f"{i}week" for i in range(1,9)]
    header2 = ["", "", ""] + [f"{i}week" for i in range(9,17)]
    table_data = [header1, header2]

    # 학생 데이터 2행씩 추가
    for sid, name, dept in students:
        row1 = [sid, Paragraph(name, name_style), dept] + [""]*8
        row2 = ["", "", ""] + [""]*8
        table_data.extend([row1, row2])

    col_widths = [50, 150, 120] + [25]*8
    table = Table(table_data, colWidths=col_widths, repeatRows=2)

    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,1), colors.HexColor("#4F81BD")),
        ('TEXTCOLOR', (0,0), (-1,1), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('FONTNAME', (0,0), (-1,1), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,1), 9),
        ('FONTSIZE', (0,2), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,1), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.black),
        ('ROWBACKGROUNDS', (2,2), (-1,-1), [colors.white, colors.lightgrey])
    ]))

    elements.append(table)
    doc.build(elements)

# ----------------------------
# Flask 라우트
# ----------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    sections = get_sections()  # 모든 섹션 조회
    if request.method == "POST":
        course_id = request.form.get("course_id")
        sec_id = request.form.get("sec_id")
        semester = request.form.get("semester")
        year = request.form.get("year")

        if course_id and sec_id and semester and year:
            # 선택한 섹션 학생 조회
            students = get_students(course_id, sec_id, semester, year)
            if not students:
                return "No students found for this selection."

            # course_id → course_title로 표시용
            course_title = next((row[1] for row in sections if str(row[0])==course_id), "Unknown")
            filename = f"{course_title}_{sec_id}_attendance.pdf"
            create_attendance_pdf(course_title, sec_id, semester, year, students, filename)
            return send_file(filename, as_attachment=True)

    return render_template("index.html", sections=sections)

if __name__ == "__main__":
    app.run(debug=True)
